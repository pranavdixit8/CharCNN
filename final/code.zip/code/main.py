# models - RNN, LSTM, GRU, BOW
# 
#
#
#
#
#
from __future__ import print_function

import os
import sys
import string
from datetime import datetime
import cPickle

from keras.models import model_from_json
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers import LSTM
from keras.datasets import imdb


import numpy as np
from Data import *

#print twitter_samples.fileids();

## GLOBAL PARAMETERS
maxlen = 80
batch_size = 32
train = 1
test = 1


num_lables = None

## LOAD AND PREPROCESS DATA
# arg1 - data_source - 'nltk'/'semeval'
# arg2 - w2v_source - 'data'/'google'
data = Data('nltk', 'data')

x_words,x_train,y_train = data.data,data.vec_data,data.y

print('Pad sequences (samples x time)')
x_train = sequence.pad_sequences(x_train, maxlen=maxlen)
#x_test = sequence.pad_sequences(x_test, maxlen=maxlen)
print('x_train shape:', x_train.shape)
#print('x_test shape:', x_test.shape)

num_lables = data.num_lables

'''print '1'
#print data.data
for toks in data.data[:5]:
    print(toks)

print '2'
#print data.data
for vec in data.vec_data[:1]:
    print(vec)
'''


## LOAD PRETRAINED WORD2VEC



## TRAIN WORD2VEC



## TRAIN MODEL

print('Build model...')
model = Sequential()
#model.add(Embedding(max_features, 128))
model.add(LSTM(100, input_shape=(80,100),dropout=0.2, recurrent_dropout=0.2))
model.add(Dense(1, activation='sigmoid'))

# try using different optimizers and different optimizer configs
model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

print('Train...')
model.fit(x_train, y_train,
          batch_size=num_lables,
          epochs=2)
 #         validation_data=(x_test, y_test))
score, acc = model.evaluate(x_train, y_train,
                            batch_size=batch_size)



# serialize model to JSON
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)
# serialize weights to HDF5
model.save_weights("model.h5")
print("Saved model to disk")
 
# later...
 
# load json and create model
json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights("model.h5")
print("Loaded model from disk")
 
# evaluate loaded model on test data
loaded_model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
score = loaded_model.evaluate(x_train, y_train, verbose=0)
print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))

## TEST MODEL



